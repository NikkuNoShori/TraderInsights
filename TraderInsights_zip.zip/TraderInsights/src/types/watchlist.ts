export interface WatchlistColumn {
  id: string;
  label: string;
  visible: boolean;
  width?: number;
  order?: number;
}