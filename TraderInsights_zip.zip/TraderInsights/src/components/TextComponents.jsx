export function TextComponents() {
  return (
    <div>
      <p className="text-gray-900 dark:text-gray-200">
        Content here
      </p>
      <h1 className="text-gray-900 dark:text-gray-100">
        Heading here
      </h1>
    </div>
  );
} 