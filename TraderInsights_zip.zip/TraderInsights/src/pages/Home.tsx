import React from 'react';

export default function Home() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Welcome to Stocked</h1>
      <p className="mt-4">Your personal stock trading companion</p>
    </div>
  );
} 